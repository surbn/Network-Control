package com.example.shizuku5gswitch

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlinx.coroutines.*

class NetworkTileService : TileService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            label = "4G / 5G Switch"
            subtitle = "Device driver required"
            state = Tile.STATE_INACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        // Safe default: no blind radio setting writes from a tile tap.
        scope.launch {
            val message = RootNetworkController.setMode(NetworkMode.AUTO)
            withContext(Dispatchers.Main) {
                qsTile?.apply {
                    subtitle = if (message.startsWith("Not changed")) "Unsupported device" else "Check app"
                    state = Tile.STATE_INACTIVE
                    updateTile()
                }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
