package com.example.shizuku5gswitch

import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

enum class NetworkMode { LTE_ONLY, NR_ONLY, AUTO }

/**
 * Deliberately fail-closed.
 *
 * Android has no public, cross-OEM API that lets an ordinary app force LTE-only
 * or NR-only. The privileged TelephonyManager API is permission protected and
 * modem/OEM implementations differ. This controller never writes undocumented
 * settings or guesses `service call` transaction IDs.
 *
 * Add a verified device-family driver only after testing its exact Android build,
 * modem and SIM configuration. Until then the app reports unsupported and makes
 * no radio changes.
 */
object RootNetworkController {
    private fun root(command: String): Pair<Int, String> {
        val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
        val done = process.waitFor(4, TimeUnit.SECONDS)
        if (!done) {
            process.destroyForcibly()
            return -1 to "Root command timed out."
        }
        return process.exitValue() to output
    }

    fun diagnose(): String {
        val (code, output) = root("id")
        if (code != 0 || !output.contains("uid=0")) {
            return "Root access unavailable or not approved. Grant root access to this app in your superuser manager, then refresh."
        }
        val sdk = android.os.Build.VERSION.SDK_INT
        val manufacturer = android.os.Build.MANUFACTURER
        val model = android.os.Build.MODEL
        return "Root access: available\nDevice: $manufacturer $model\nAndroid API: $sdk\nRadio driver: not yet verified for this device. LTE ONLY / NR ONLY are disabled until a tested OEM/modem driver is available."
    }

    fun setMode(mode: NetworkMode): String {
        val (code, output) = root("id")
        if (code != 0 || !output.contains("uid=0")) {
            return "Not changed: root permission was not granted."
        }
        return when (mode) {
            NetworkMode.LTE_ONLY -> "Not changed: this device has no verified LTE-only driver in this build. No undocumented modem command was attempted."
            NetworkMode.NR_ONLY -> "Not changed: this device has no verified NR-only driver in this build. NR-only may also remove voice/VoLTE/VoNR service depending on carrier support."
            NetworkMode.AUTO -> "Not changed: automatic mode is already controlled by Android/carrier settings. A verified device driver is required to modify it safely."
        }
    }
}
