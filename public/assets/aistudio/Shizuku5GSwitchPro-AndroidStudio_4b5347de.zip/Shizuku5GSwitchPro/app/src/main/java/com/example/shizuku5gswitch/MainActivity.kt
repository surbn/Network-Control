package com.example.shizuku5gswitch

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF0A1020)
private val Panel = Color(0xFF151F33)
private val Blue = Color(0xFF78A9FF)
private val Mint = Color(0xFF78E0C0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Blue,
            onBackground = Color.White, onSurface = Color.White
        )) { Dashboard() } }
    }
}

@Composable
private fun Dashboard() {
    var status by remember { mutableStateOf("Checking root access…") }
    var result by remember { mutableStateOf("No network mode has been changed.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        status = withContext(Dispatchers.IO) { RootNetworkController.diagnose() }
    }

    fun switch(mode: NetworkMode) {
        scope.launch {
            busy = true
            result = withContext(Dispatchers.IO) { RootNetworkController.setMode(mode) }
            status = withContext(Dispatchers.IO) { RootNetworkController.diagnose() }
            busy = false
        }
    }

    Scaffold(containerColor = Ink) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 22.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Blue, Color(0xFF766BFF))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.CellTower, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("SHIZUKU 5G", fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                    Text("NETWORK CONTROL PRO", color = Color(0xFF9EABC3), fontSize = 10.sp, letterSpacing = 1.6.sp)
                }
                Surface(color = Color(0xFF173C35), shape = RoundedCornerShape(50)) {
                    Text("ROOT MODE", Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(28.dp)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NETWORK CONTROL", color = Color(0xFF9EABC3), fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(12.dp))
                    Icon(Icons.Rounded.SettingsInputAntenna, null, tint = Blue, modifier = Modifier.size(42.dp))
                    Text("4G  ⇄  5G", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Device compatibility is checked before any change", color = Color(0xFF9EABC3), fontSize = 11.sp)
                    Spacer(Modifier.height(22.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ModeButton("LTE ONLY", "4G", Icons.Rounded.SignalCellularAlt, Modifier.weight(1f), busy) { switch(NetworkMode.LTE_ONLY) }
                        ModeButton("NR ONLY", "5G", Icons.Rounded.CellTower, Modifier.weight(1f), busy) { switch(NetworkMode.NR_ONLY) }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { switch(NetworkMode.AUTO) }, enabled = !busy, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Rounded.AutoMode, null)
                        Spacer(Modifier.width(8.dp))
                        Text("AUTO / 4G + 5G")
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Security, null, tint = Mint)
                        Spacer(Modifier.width(8.dp))
                        Text("COMPATIBILITY DIAGNOSTICS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    AnimatedContent(status, label = "diagnostics") { value ->
                        Text(value, color = Color(0xFFC3CEE1), fontSize = 12.sp, lineHeight = 18.sp)
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.NotificationsActive, null, tint = Blue)
                        Spacer(Modifier.width(8.dp))
                        Text("QUICK SETTINGS TILE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    Text("Add “4G / 5G Switch” from Android’s Quick Settings edit screen. Tile actions use the same guarded controller.", color = Color(0xFF9EABC3), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }

            Text(result, color = Color(0xFFB6C2D6), fontSize = 11.sp, lineHeight = 16.sp)
            Spacer(Modifier.weight(1f))
            Text("No universal modem command exists. Unsupported devices are left unchanged.", color = Color(0xFF78869E), fontSize = 10.sp)
        }
    }
}

@Composable
private fun ModeButton(label: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, busy: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = !busy, modifier = modifier.height(82.dp), shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(8.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null)
            Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(subtitle, fontSize = 10.sp)
        }
    }
}
