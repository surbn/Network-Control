# Shizuku 5G Switch Pro — Android Studio Kotlin project

## What is included
- Kotlin + Jetpack Compose premium dark dashboard.
- LTE ONLY, NR ONLY and AUTO control surfaces.
- Android Quick Settings Tile (`4G / 5G Switch`).
- Root access diagnostic (`su -c id`).
- Shizuku API dependency included for future privileged-service integration.
- Fail-closed network controller: unsupported phones are not modified.

## Important compatibility truth
There is no single supported command/API that forces LTE-only or NR-only on every Android phone. The privileged telephony APIs, modem firmware, carrier configuration, OEM restrictions, dual-SIM implementation and Android version differ. Root does not make one undocumented modem command universal.

This starter intentionally DOES NOT pretend the mode changed. `RootNetworkController` reports that a device-specific driver is missing and performs no radio writes. Do not replace this with guessed `settings put global preferred_network_mode` values or guessed `service call phone` transaction IDs: they can be ignored, target the wrong SIM, or break cellular service.

To enable a particular model, implement and test a dedicated `NetworkModeDriver` for that exact device/build/baseband. It must:
1. Detect exact manufacturer/model/build fingerprint and modem/baseband.
2. Verify the supported radio access bitmask/command syntax on that firmware.
3. Save the original mode and SIM/subscription mapping.
4. Apply the change, read it back, and report success only after verification.
5. Provide a timeout and restore path if cellular service is lost.
6. Keep AUTO as a recovery option.

## Build
1. Open this folder in Android Studio (Ladybug or newer).
2. Install Android SDK Platform 35 and JDK 17.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Root permission
Install a root manager such as Magisk and approve the app's root request when prompted. This project only checks that root is available; it does not silently change radio settings.

## Quick Settings tile
After installing, open the notification shade, tap Edit, and add `4G / 5G Switch`. The tile currently provides a guarded entry point; actual switching remains unavailable until a verified device driver is added.

## Shizuku
The Shizuku API dependency is present, but the initial project uses the explicitly selected root path. Shizuku is not a substitute for carrier/OEM privileged telephony permissions. A future Shizuku backend can be added for operations that the connected service actually permits.

## Current implementation status
UI, root diagnostic, and Quick Settings tile are scaffolded. Universal LTE-only / NR-only switching is NOT implemented because that claim cannot be made honestly for all Android devices.
